package gestionClinico.controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gestionClinico.entities.Paciente;

import gestionClinico.service.PacienteService;


@RestController
@RequestMapping("/pacientes")
public class PacienteController {

    @Autowired
    private PacienteService pacientesService;

     @GetMapping
    public ResponseEntity<?> getPacientes() {
        List<Paciente> pacientes = pacientesService.getPacientes();

        return ResponseEntity.ok(pacientes);
    }
    
    @GetMapping("/{userName}")
    public ResponseEntity<?> getPacienteByUserName(@PathVariable String userName) {
        Paciente paciente = pacientesService.getPacienteByUserName(userName);
        if (paciente != null) {

            return ResponseEntity.ok(paciente);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Paciente " + userName + " no encontrado");
    }

    @PostMapping
    public ResponseEntity<?> postPaciente(@RequestBody Paciente paciente) {
        Paciente creatPaciente = pacientesService.postPaciente(paciente);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Paciente " + creatPaciente.getUserName() + " creado exitosamente!");
    }

    @PutMapping
    public ResponseEntity<?> putPaciente(@RequestBody Paciente paciente) {
        Paciente updatePaciente = pacientesService.putPaciente(paciente);
        if (updatePaciente != null) {
            
            return ResponseEntity.ok(paciente);

        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("Paciente " + paciente.getUserName() + " modificado exitosamente");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePaciente(@PathVariable int id) {
        Paciente deletedPaciente = pacientesService.deletePaciente(id);
        if (deletedPaciente != null) {

            return ResponseEntity.ok("Paciente con el ID " + id + " eliminado satisfactoriamente");

        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Paciente " + id + " no encontrado");
    }
    @PatchMapping
    public ResponseEntity<?> patchPaciente(@RequestBody Paciente Paciente) {
        Paciente patchedPaciente = pacientesService.patchPaciente(Paciente);
        if (patchedPaciente != null) {

            return ResponseEntity.ok(patchedPaciente);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Paciente con ID " + Paciente.getId() + " no encontrado");
    }    
}