package gestionClinico.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gestionClinico.entities.Medico;
import gestionClinico.service.MedicoService;

@RestController
@RequestMapping("/medicos")
public class MedicoController {
    
 
    @Autowired
    private MedicoService medicosService;
    
    @GetMapping
    public ResponseEntity<?> getMedicos() {
        List<Medico> medicos = medicosService.getMedicos();

        return ResponseEntity.ok(medicos);
    }

    @GetMapping("/{userName}")
    public ResponseEntity<?> getMedicoByUserName(@PathVariable String userName) {
        Medico medico = medicosService.getMedicoByUserName(userName);
        if (medico != null) {

            return ResponseEntity.ok(medico);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Medico " + userName + " no encontrado");
    }

    @PostMapping
    public ResponseEntity<?> postMedico(@RequestBody Medico medico) {
        Medico creatMedico = medicosService.postMedico(medico);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Medico " + creatMedico.getUserName() + " creado exitosamente!");
    }

    @PutMapping
    public ResponseEntity<?> putMedico(@RequestBody Medico medico) {
        Medico updateMedico = medicosService.putMedico(medico);
        if (updateMedico != null) {
            
            return ResponseEntity.ok(medico);

        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("Medico " + medico.getUserName() + " modificado exitosamente");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteMedico(@PathVariable int id) {
        Medico deletedMedico = medicosService.deleteMedico(id);
        if (deletedMedico != null) {

            return ResponseEntity.ok("Medico con el ID " + id + " eliminado satisfactoriamente");

        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Medico con el ID " + id + " no encontrado");
    }
    @PatchMapping
    public ResponseEntity<?> patchMedico(@RequestBody Medico medico) {
        Medico patchMedico = medicosService.patchMedico(medico);
        if (patchMedico != null) {
            
            return ResponseEntity.ok(patchMedico);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Medico con ID " + medico.getId() + " no encontrado");
    }

}
