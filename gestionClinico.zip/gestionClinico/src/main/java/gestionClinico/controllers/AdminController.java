package gestionClinico.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gestionClinico.entities.Admin;
import gestionClinico.service.AdminService;

@RestController
@RequestMapping("/admins")
// clase adminController depende de getAdmins que corresponde a otro bjeto
// adminsService
public class AdminController {

    // AdminService adminsService = new AdminsServiceImpl(); // polimorfismo
    // dinamico
    @Autowired
    private AdminService adminsService; // inyeccion de dependencia por campo, con el atributo de la clase

    @GetMapping
    public ResponseEntity<?> getAdmins() {
        List<Admin> admins = adminsService.getAdmins();

        return ResponseEntity.ok(admins);
    }

    @GetMapping("/{userName}")
    public ResponseEntity<?> getAdminByUserName(@PathVariable String userName) {
        Admin admin = adminsService.getAdminByUserName(userName);
        if (admin != null) {

            return ResponseEntity.ok(admin);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Administrador " + userName + " no encontrado");
    }

    @PostMapping
    public ResponseEntity<?> postAdmin(@RequestBody Admin admin) {
        Admin creatAdmin = adminsService.postAdmin(admin);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Administrador " + creatAdmin.getUserName() + " creado exitosamente!");
    }

    @PutMapping
    public ResponseEntity<?> putAdmin(@RequestBody Admin admin) {
        Admin updateAdmin = adminsService.putAdmin(admin);
        if (updateAdmin != null) {
            
            return ResponseEntity.ok(admin);

        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("Administrador " + admin.getUserName() + " modificado exitosamente");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteAdmin(@PathVariable int id) {
        Admin deletedAdmin = adminsService.deleteAdmin(id);
        if (deletedAdmin != null) {

            return ResponseEntity.ok("Administrador con el ID " + id + " eliminado satisfactoriamente");

        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Administrador con el ID " + id + " no encontrado");
    }
    @PatchMapping
    public ResponseEntity<?> patchAdmin(@RequestBody Admin admin) {
        Admin patchedAdmin = adminsService.patchAdmin(admin);
        if (patchedAdmin != null) {
            
            return ResponseEntity.ok(patchedAdmin);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Administrador con ID " + admin.getId() + " no encontrado");
    }

}
