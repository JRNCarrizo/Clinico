package gestionClinico.entities;

import lombok.AllArgsConstructor;
import lombok.Data;


@Data
@AllArgsConstructor
public class Paciente {
    
    private Integer id;
    private String nombre;
    private String apellido;
    //TODO - agregar fecha de nacimiento
    private String direccion;
    //TODO - enum del tipo de documento
    private String documento; 
    private String telefono;
    private String whatsapp;
    private String mail;
    private String userName;
    private String password;
    //TODO - historialClinico 

    public Paciente() {

    }
}
