package gestionClinico.entities;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Medico {
    
    private Integer idMedico;
    //TODO - agregar enum con especialidad medica
    private String nombre;
    private String apellido;
    private String numMatricula;
    private String doc;
    private String telefono;
    private String whatsapp;
    private String mail;
    private String userName;
    private String password;
    
    public Medico() {

    }
}
