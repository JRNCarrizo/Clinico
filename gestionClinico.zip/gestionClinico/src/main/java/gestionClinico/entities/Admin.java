package gestionClinico.entities;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Admin {

    private Integer idAdmin;
    private String nombre;
    private String apellido;
    private String userName;
    private String password;

    public Admin() {

    }
}