package gestionClinico.service;

import java.util.List;


import gestionClinico.entities.Paciente;

public interface PacienteService {

    List<Paciente> getPacientes();
    
    Paciente getPacienteByUserName(String userName);

    Paciente postPaciente(Paciente Paciente);

    Paciente deletePaciente(Integer id);

    Paciente putPaciente(Paciente Paciente);

    Paciente patchPaciente(Paciente Paciente);
        

}
