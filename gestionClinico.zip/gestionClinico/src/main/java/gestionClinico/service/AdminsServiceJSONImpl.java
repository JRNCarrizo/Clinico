// package gestionClinico.service;

// import java.io.File;
// import java.io.FileInputStream;
// import java.io.IOException;
// import java.io.InputStream;
// import java.util.List;
// import java.util.Optional;

// import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
// import org.springframework.stereotype.Service;

// import com.fasterxml.jackson.core.type.TypeReference;
// import com.fasterxml.jackson.databind.ObjectMapper;

// import gestionClinico.entities.Admin;

// @Service
// @ConditionalOnProperty(name = "service.admins", havingValue = "Json")
// public class AdminsServiceJSONImpl implements AdminService {

//     //Ruta al archivo json
//     private final String FILE_PATH = "/js/admins.json"; 
//     private ObjectMapper objectMapper = new ObjectMapper(); // Mapeador JSON

//     private List<Admin> loadAdmins() throws IOException {
//     InputStream inputStream = new FileInputStream(new File("/js/admins.json"));
//     return objectMapper.readValue(inputStream, new TypeReference<List<Admin>>() {});
// }

//     // Método para cargar el archivo JSON
//     // private List<Admin> loadAdmins() throws IOException {
//     //     return objectMapper.readValue(new File(FILE_PATH), new TypeReference<List<Admin>>() {});
//     // }

//     // Método para guardar el archivo JSON
//     private void saveAdmins(List<Admin> admins) throws IOException {
//         objectMapper.writeValue(new File(FILE_PATH), admins);
//     }

//     @Override
//     public List<Admin> getAdmins() {
//         List<Admin> admins;
//         try {
//             admins = new ObjectMapper()
//             .readValue(this.getClass().getResourceAsStream("/js/admins.json"),
//             new TypeReference<List<Admin>>() {});

//             return admins;
//         } catch (IOException e) {
//             throw new RuntimeException("Error al leer el archivo JSON", e);

//         }
//     }

//     @Override
//     public Admin getAdminByUserName(String userName) {
//         try {
//             List<Admin> admins = loadAdmins();
//             return admins.stream()
//                     .filter(admin -> admin.getUserName().equalsIgnoreCase(userName))
//                     .findFirst()
//                     .orElse(null);
//         } catch (IOException e) {
//             throw new RuntimeException("Error al leer el archivo JSON", e);
//         }
//     }

//     @Override
//     public Admin postAdmin(Admin admin) {
//         try {
//             List<Admin> admins = loadAdmins();
//             admins.add(admin); // Añadir nuevo administrador
//             saveAdmins(admins); // Guardar cambios en JSON
//             return admin;
//         } catch (IOException e) {
//             throw new RuntimeException("Error al escribir en el archivo JSON", e);
//         }
//     }

//     @Override
//     public Admin deleteAdmin(Integer id) {
//         try {
//             List<Admin> admins = loadAdmins();
//             Optional<Admin> adminToRemove = admins.stream()
//                     .filter(admin -> admin.getId().equals(id))
//                     .findFirst();

//             if (adminToRemove.isPresent()) {
//                 admins.remove(adminToRemove.get());
//                 saveAdmins(admins); // Guardar cambios en JSON
//                 return adminToRemove.get();
//             }

//             return null;
//         } catch (IOException e) {
//             throw new RuntimeException("Error al escribir en el archivo JSON", e);
//         }
//     }

//     public Admin putAdmin(Admin admin) {
//         try {
//             List<Admin> admins = loadAdmins(); // Cargar la lista de administradores
//             for (int i = 0; i < admins.size(); i++) {
//                 if (admins.get(i).getId().equals(admin.getId())) {
//                     admins.set(i, admin); // Reemplazar el administrador
//                     saveAdmins(admins); // Guardar cambios en JSON
//                     return admin;
//                 }
//             }
//             return null; // Si no se encontró el administrador
//         } catch (IOException e) {
//             throw new RuntimeException("Error al escribir en el archivo JSON", e);
//         }
//     }

//     @Override
//     public Admin patchAdmin(Admin admin) {
//         try {
//             List<Admin> admins = loadAdmins();
//             for (Admin a : admins) {
//                 if (a.getId().equals(admin.getId())) { 

//                     if (admin.getNombre() != null) {
//                         a.setNombre(admin.getNombre());
//                     }
//                     if (admin.getUserName() != null) {
//                         a.setUserName(admin.getUserName());
//                     }
//                     if (admin.getPassword() != null) {
//                         a.setPassword(admin.getPassword());
//                     }
//                     saveAdmins(admins);
//                     return a;
//                 }
//             }
//             return null; 
//         } catch (IOException e) {
//             throw new RuntimeException("Error al escribir en el archivo JSON", e);
//         }
//     }
// }
