package gestionClinico.service;

import java.util.List;

import gestionClinico.entities.Medico;

public interface MedicoService {
    
    List<Medico> getMedicos();
    
    Medico getMedicoByUserName(String userName);

    Medico postMedico(Medico medico);

    Medico deleteMedico(Integer id);

    Medico putMedico(Medico medico);

    Medico patchMedico(Medico medico);
}
