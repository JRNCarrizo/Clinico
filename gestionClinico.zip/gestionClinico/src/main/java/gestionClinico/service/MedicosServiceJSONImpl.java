// package gestionClinico.service;

// import java.io.IOException;
// import java.util.List;

// import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
// import org.springframework.stereotype.Service;

// import com.fasterxml.jackson.core.type.TypeReference;
// import com.fasterxml.jackson.databind.ObjectMapper;

// import gestionClinico.entities.Medico;

// @Service
// @ConditionalOnProperty(name = "service.medicos", havingValue = "Json")
// public class MedicosServiceJSONImpl implements MedicoService {

//     @Override
//     public List<Medico> getMedicos() {
//         List<Medico> medicos;

//         try {
//             medicos = new ObjectMapper()
//             .readValue(this.getClass()
//             .getResourceAsStream("/medicos.json"),
//             new TypeReference<List<Medico>>(){});

//         return medicos;
            
//         } catch (IOException e) {
//             throw new RuntimeException(e);
//         }
//     }
    
// }
