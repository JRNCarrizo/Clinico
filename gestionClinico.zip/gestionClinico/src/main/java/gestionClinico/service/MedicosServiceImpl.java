package gestionClinico.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import gestionClinico.entities.Medico;

@Service
@ConditionalOnProperty(name = "service.medicos", havingValue = "List")

public class MedicosServiceImpl implements MedicoService {
    
    List<Medico> medicos = new ArrayList<>(Arrays. asList(
        new Medico(1, "Juan", "Pérez", "M12345", "1234567890", "1234567890", "juan.perez@hospital.com", "juanperez", "medico123"),
        new Medico(2, "María", "Gómez", "M67890", "0987654321", "0987654321", "maria.gomez@hospital.com", "mariagomez", "password456"),
        new Medico(3, "Carlos", "López", "M23456", "4567890123", "4567890123", "carlos.lopez@hospital.com", "carloslopez", "secure789"),
        new Medico(4, "Ana", "Martínez", "M34567", "2345678901", "2345678901", "ana.martinez@hospital.com", "anamartinez", "ana321"),   
        new Medico(5, "Luis", "Ramírez", "M45678", "3216549870", "3216549870", "luis.ramirez@hospital.com", "luisramirez", "luis654")  
    ));
    
    @Override
    public List<Medico> getMedicos() {

        return medicos;
    }

    @Override
    public Medico getMedicoByUserName(String userName) {
        for (Medico medico : medicos)
            if (medico.getUserName().equalsIgnoreCase(userName)) {

                return medico;
            }
        return null;
    }

    @Override
    public Medico postMedico(Medico medico) {
        medicos.add(medico);

        return medico;
    }

    @Override
    public Medico deleteMedico(Integer id) {
        for (Medico m : medicos) {
            if (m.getId() == id) {
                medicos.remove(m);

                return m;
            }
        }
        return null;
    }

    @Override
    public Medico putMedico(Medico medico) {
        for (Medico m : medicos) {
            if (m.getId() == medico.getId()) {
                m.setNombre(medico.getNombre());
                m.setApellido(medico.getApellido());
                m.setNumMatricula(medico.getNumMatricula());
                m.setTelefono(medico.getTelefono());
                m.setWhatsapp(medico.getWhatsapp());
                m.setMail(medico.getMail());
                m.setUserName(medico.getUserName());
                m.setPassword(medico.getPassword());

                return m;
            }
        }
        return null;
    }

    @Override
    public Medico patchMedico(Medico medico) {
        for (Medico m : medicos) {
            if (m.getId() == medico.getId()) {

                if (medico.getNombre() != null) {
                    m.setNombre(medico.getNombre());
                }
                if (medico.getApellido() != null) {
                    m.setApellido(medico.getApellido());
                }
                if (medico.getNumMatricula() != null) {
                    m.setNumMatricula(medico.getNumMatricula());
                }
                if (medico.getTelefono() != null) {
                    m.setTelefono(medico.getTelefono());
                }
                if (medico.getWhatsapp() != null) {
                    m.setWhatsapp(medico.getWhatsapp());
                }
                if (medico.getMail() != null) {
                    m.setMail(medico.getMail());
                }
                if (medico.getUserName() != null) {
                    m.setUserName(medico.getUserName());
                }
                if (medico.getPassword() != null) {
                    m.setPassword(medico.getPassword());
                }

                return m;
            }
        }
        return null;
    }
}