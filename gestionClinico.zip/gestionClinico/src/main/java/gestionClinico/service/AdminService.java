package gestionClinico.service;

import java.util.List;

import gestionClinico.entities.Admin;

// metodo abstracto que solo se define y no se implementa en la interface
public interface AdminService {

    List<Admin> getAdmins();
    
    Admin getAdminByUserName(String userName);

    Admin postAdmin(Admin admin);

    Admin deleteAdmin(Integer id);

    Admin putAdmin(Admin admin);

    Admin patchAdmin(Admin admin);
}
