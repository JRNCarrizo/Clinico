package gestionClinico.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import gestionClinico.entities.Paciente;

@Service
@ConditionalOnProperty(name = "service.pacientes", havingValue = "List")
public class PacientesServiceImpl implements PacienteService {
    
    List<Paciente> pacientes = new ArrayList<>(Arrays.asList(
        new Paciente(1, "Juan", "Pérez", "Calle 123", "12345678", "1234567890", "1234567890", "juan.perez@mail.com", "juanperez", "password123"),
        new Paciente(2, "María", "Gómez", "Avenida 45", "87654321", "0987654321", "0987654321", "maria.gomez@mail.com", "mariagomez", "maria456"),
        new Paciente(3, "Carlos", "López", "Calle Real 8", "23456789", "4567890123", "4567890123", "carlos.lopez@mail.com", "carloslopez", "carlos789"),
        new Paciente(4, "Ana", "Martínez", "Boulevard 76", "34567890", "2345678901", "2345678901", "ana.martinez@mail.com", "anamartinez", "ana321"),
        new Paciente(5, "Luis", "Hernández", "Carrera 54", "45678901", "3216549870", "3216549870", "luis.hernandez@mail.com", "luishernandez", "luis654"),
        new Paciente(6, "Laura", "Ramírez", "Calle del Sol 27", "56789012", "5678901234", "5678901234", "laura.ramirez@mail.com", "lauraramirez", "laura987"),
        new Paciente(7, "Pedro", "Torres", "Avenida Central 10", "67890123", "6789012345", "6789012345", "pedro.torres@mail.com", "pedrotorres", "pedro321"),
        new Paciente(8, "Sofía", "Sánchez", "Calle Luna 22", "78901234", "7890123456", "7890123456", "sofia.sanchez@mail.com", "sofiasanchez", "sofia654"),
        new Paciente(9, "David", "Ortiz", "Paseo de la Paz 19", "89012345", "8901234567", "8901234567", "david.ortiz@mail.com", "davidortiz", "david987"),
        new Paciente(10, "Julia", "Castillo", "Plaza Mayor 5", "90123456", "9012345678", "9012345678", "julia.castillo@mail.com", "juliacastillo", "julia123")
    ));

    @Override
    public List<Paciente> getPacientes() {

        return pacientes;
    }

    @Override
    public Paciente getPacienteByUserName(String userName) {
        for (Paciente p : pacientes)
            if (p.getUserName().equalsIgnoreCase(userName)) {

                return p;
            }
        return null;
    }

    @Override
    public Paciente postPaciente(Paciente paciente) {
        pacientes.add(paciente);

        return paciente;
    }

    @Override
    public Paciente deletePaciente(Integer id) {
        for (Paciente p : pacientes) {
            if (p.getId() == id) {
                pacientes.remove(p);

                return p;
            }
        }
        return null;
    }

    @Override
    public Paciente putPaciente(Paciente paciente) {
        for (Paciente p : pacientes) {
            if (p.getId() == paciente.getId()) {
                p.setNombre(paciente.getNombre());
                p.setApellido(paciente.getApellido());
                p.setDireccion(paciente.getDireccion());
                p.setDocumento(paciente.getDocumento());
                p.setTelefono(paciente.getTelefono());
                p.setWhatsapp(paciente.getWhatsapp());
                p.setMail(paciente.getMail());
                p.setUserName(paciente.getUserName());
                p.setPassword(paciente.getPassword());

                return p;
            }
        }
        return null;
    }

    @Override
    public Paciente patchPaciente(Paciente paciente) {
        for (Paciente p : pacientes) {
            if (p.getId() == paciente.getId()) {

                if (paciente.getNombre() != null) {
                    p.setNombre(paciente.getNombre());
                }
                if (paciente.getApellido() != null) {
                    p.setApellido(paciente.getApellido());
                }
                if (paciente.getDireccion() != null) {
                    p.setDireccion(paciente.getDireccion());
                }
                if (paciente.getDocumento() != null) {
                    p.setDocumento(paciente.getDocumento());
                }
                if (paciente.getTelefono() != null) {
                    p.setTelefono(paciente.getTelefono());
                }
                if (paciente.getWhatsapp() != null) {
                    p.setWhatsapp(paciente.getWhatsapp());
                }
                if (paciente.getMail() != null) {
                    p.setMail(paciente.getMail());
                }
                if (paciente.getUserName() != null) {
                    p.setUserName(paciente.getUserName());
                }
                if (paciente.getPassword() != null) {
                    p.setPassword(paciente.getPassword());
                }

                return p;
            }
        }
        return null;
    }
}
