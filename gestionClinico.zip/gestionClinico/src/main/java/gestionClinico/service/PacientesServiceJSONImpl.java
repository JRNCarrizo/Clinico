// package gestionClinico.service;

// import java.io.IOException;
// import java.util.List;

// import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
// import org.springframework.stereotype.Service;

// import com.fasterxml.jackson.core.type.TypeReference;
// import com.fasterxml.jackson.databind.ObjectMapper;

// import gestionClinico.entities.Paciente;

// @Service
// @ConditionalOnProperty(name = "service.pacientes", havingValue = "Json")
// public class PacientesServiceJSONImpl implements PacienteService {

//     @Override
//     public List<Paciente> getPacientes() {
//         List<Paciente> admins;

//         try {
//             admins = new ObjectMapper()
//                     .readValue(this.getClass()
//                             .getResourceAsStream("/admins.json"),
//                             new TypeReference<List<Paciente>>() {
//                             });

//             return admins;

//         } catch (IOException e) {
//             throw new RuntimeException(e);
//         }
//     }
// }
