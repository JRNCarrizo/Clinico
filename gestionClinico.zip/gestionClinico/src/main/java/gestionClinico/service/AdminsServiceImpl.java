package gestionClinico.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import gestionClinico.entities.Admin;

@Service
@ConditionalOnProperty(name = "service.admins", havingValue = "List")

public class AdminsServiceImpl implements AdminService {

    List<Admin> admins = new ArrayList<>(Arrays.asList(
            new Admin(1, "Carlos Ruiz", "carlos_ruiz", "admin123"),
            new Admin(2, "Lucía Fernández", "lucia_fernandez", "password456"),
            new Admin(3, "Veterinaria Huellas", "vet_huellas", "huellas789"),
            new Admin(4, "Cruz Roja", "cruz_roja", "cruspass321"),
            new Admin(5, "Medicos Sin Fronteras", "sin_fronteras", "sinfront654")));

    // esta clase implementa el metodo de la interface
    @Override
    public List<Admin> getAdmins() {

        return admins;
    }

    @Override
    public Admin getAdminByUserName(String userName) {
        for (Admin a : admins)
            if (a.getUserName().equalsIgnoreCase(userName)) {

                return a;
            }
        return null;
    }

    @Override
    public Admin postAdmin(Admin admin) {
        admins.add(admin);

        return admin;
    }

    @Override
    public Admin deleteAdmin(Integer id) {
        for (Admin a : admins) {
            if (a.getId() == id) {
                admins.remove(a);

                return a;
            }
        }
        return null;
    }

    @Override
    public Admin putAdmin(Admin admin) {
        for (Admin a : admins) {
            if (a.getId() == admin.getId()) {
                a.setNombre(admin.getNombre());
                a.setUserName(admin.getUserName());
                a.setPassword(admin.getPassword());

                return a;
            }
        }
        return null;
    }

    @Override
    public Admin patchAdmin(Admin admin) {
        for (Admin a : admins) {
            if (a.getId() == admin.getId()) {

                if (admin.getNombre() != null) {
                    a.setNombre(admin.getNombre());
                }
                if (admin.getUserName() != null) {
                    a.setUserName(admin.getUserName());
                }
                if (admin.getPassword() != null) {
                    a.setPassword(admin.getPassword());
                }

                return a;
            }
        }
        return null;
    }

}
