package gestionClinico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGestionClinicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGestionClinicoApplication.class, args);
	}

}
