-- Active: 1728862036101@@127.0.0.1@3306@gestionclinico
drop database if exists gestionclinico;
create database gestionclinico;
use gestionclinico;

drop table if exists admin;

create table admin(
    idAdmin int AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    username VARCHAR(50)NOT NULL,
    password VARCHAR(50) NOT NULL
);

create table medico(
    idMedico int AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    doc VARCHAR(50) NOT NULL,
    numMatricula VARCHAR(50) NOT NULL,
    telefono VARCHAR(50) NOT NULL,
    whatsapp VARCHAR(50) NOT NULL,
    mail VARCHAR(50) NOT NULL,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL
);